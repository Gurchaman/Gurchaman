﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Vintri_Exercise.Filters;
using Vintri_Exercise.Models;
using Vintri_Exercise.Services;

namespace Vintri_Exercise.Controllers
{
    [ApiController]
    [Route("API/")]
    public class BeerController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;
        IList<BeerDetailsModel> objBeerDetails = new List<BeerDetailsModel>();

        public BeerController(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _cache = memoryCache;
        }


        /// <summary>
        /// Method to search beer details
        /// </summary>
        /// <param name="objBeerName">Name of the Beer</param>
        /// <returns>Returns matching results</returns>
        [HttpGet]
        [Route("Beer/GetBeerDetails")]
        public ActionResult GetBeerDetails()
        {
            List<SaveBeerRatingsModel> listBeerRatingsModel = new List<SaveBeerRatingsModel>();
            string strBeerName = String.Empty;

            try
            {
               // HttpContext.Request.QueryString = new QueryString("?beer_name=Buzz");
                strBeerName = HttpContext.Request.Query["Beer"].ToString();

                if (!string.IsNullOrEmpty(strBeerName))
                {
                    objBeerDetails = GetAllBeerDetails(strBeerName);

                    var varFilePath = @"./Database/Database.json";
                    var varJsonData = System.IO.File.ReadAllText(varFilePath);
                    listBeerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(varJsonData);

                    var varBeerData = from beers in objBeerDetails
                                      join ratings in listBeerRatingsModel
                                      on beers.id equals ratings.Id
                                      select new
                                      {
                                          id = beers.id,
                                          name = beers.name,
                                          description = beers.description,
                                          userRatings = ratings.UserRatings
                                      };

                    return new JsonResult(varBeerData);
                }
                else
                    return new JsonResult(new EmptyResult());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());    // In real world, would log this message in the system log file or the Log database
                return new JsonResult(new EmptyResult());
            }
        }


        /// <summary>
        /// Adds Ratings for a Beer
        /// </summary>
        /// <param name="ID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings in the range of 1 and 5</param>
        /// <returns>Success/failur message</returns>
        [HttpPost]
        [Route("Beer/AddRatings/{ID}")]
        [MyActionFilter]
        public ActionResult AddRatings(int ID, [FromBody] UserRatingsModel objUserRatings)
        {
            string strMessage = string.Empty;

            try
            {
                if (RouteData.Values["InvalidUserName"] != null)
                    return new JsonResult(new { Message = RouteData.Values["InvalidUserName"] });

                strMessage = Validations(ID, objUserRatings);

                if (string.IsNullOrEmpty(strMessage))
                {
                    SaveToJSONDatabase(ID, objUserRatings);
                    return new JsonResult(new { Message = Messages.SuccessRating });
                }
                else
                {
                    return new JsonResult(new { Message = strMessage });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());          // In real world, would log this message in the system log file or database
                return new JsonResult(new { Message = Messages.Error });
            }
        }

        /// <summary>
        /// Saves data to the JSON Database
        /// </summary>
        /// <param name="objID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings of the beer</param>
        /// <returns></returns>
        private void SaveToJSONDatabase(int objID, UserRatingsModel objUserRatings)
        {
            string data = string.Empty;
            bool blnExistingBeer = false;
            bool blnExistingBeerForUser = false;
            var filePath = @"./Database/Database.json";
            List<SaveBeerRatingsModel> listBeerRatingsModel = new List<SaveBeerRatingsModel>();

            var jsonData = System.IO.File.ReadAllText(filePath);

            // If the file is empty
            if (jsonData == null || jsonData == "")
            {
                listBeerRatingsModel.Insert(0, AddRatingsToABeer(objID, objUserRatings));
            }
            else
            {
                listBeerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(jsonData);

                foreach (SaveBeerRatingsModel itemBeer in listBeerRatingsModel)
                {
                    if (itemBeer.Id.Equals(objID))
                    {
                        blnExistingBeer = true;

                        foreach (UserRatingsModel itemRating in itemBeer.UserRatings)
                        {
                            if (itemRating.UserName.Equals(objUserRatings.UserName, StringComparison.OrdinalIgnoreCase))
                            {
                                blnExistingBeerForUser = true;
                                itemRating.Ratings = objUserRatings.Ratings;
                            }

                        }

                        if (!blnExistingBeerForUser)
                            itemBeer.UserRatings.Add(objUserRatings);

                    }
                }
                if (!blnExistingBeer)
                    listBeerRatingsModel.Insert(0, AddRatingsToABeer(objID, objUserRatings));
            }

            var options = new JsonSerializerOptions { WriteIndented = true };
            data = JsonSerializer.Serialize(listBeerRatingsModel, options);

            System.IO.File.WriteAllText(@"./Database/Database.json", data);  
        }


        /// <summary>
        /// Method to prepare the ratings model
        /// </summary>
        /// <param name="objID">ID of the Beer</param>
        /// <param name="objUserRatings">Rating of the beer</param>
        /// <returns>Ratings data in the form of model</returns>
        private SaveBeerRatingsModel AddRatingsToABeer(int objID, UserRatingsModel objUserRatings)
        {
            SaveBeerRatingsModel beerRatingsModel = new SaveBeerRatingsModel();

            beerRatingsModel.Id = objID;
            beerRatingsModel.UserRatings = new List<UserRatingsModel>();
            beerRatingsModel.UserRatings.Add(objUserRatings);

            return beerRatingsModel;
        }

   
        /// <summary>
        /// Validates the Rating data
        /// </summary>
        /// <param name="objID">ID of the beer</param>
        /// <param name="objUserRatings">Ratings given to the beer</param>
        /// <returns>Error message of there is any error, else empty string</returns>
        private string Validations(int objID, UserRatingsModel objUserRatings)
        {
            ExternalAPIs objExternalAPIs = new ExternalAPIs(_configuration, _cache);
            objBeerDetails = Task.Run(() => objExternalAPIs.GetBeerDetailsFromPunkAPIByID(objID)).Result;

            // Ensure the id parameter is a valid beer id
            if (objBeerDetails == null || objBeerDetails.Count < 1)
                return Messages.InValidBeerID;

            // Ensure that the rating is a valid value in the range of 1 to 5
            if (!(objUserRatings.Ratings >= 0 && objUserRatings.Ratings <= 5))
                return Messages.InValidRating;

            return string.Empty;
        }


        /// <summary>
        /// Calls the Beer Punk API method
        /// </summary>
        /// <returns>Returns details of all the beers</returns>
        private IList<BeerDetailsModel> GetAllBeerDetails(string strBeerName)
        {
            ExternalAPIs objExternalAPIs = new ExternalAPIs(_configuration, _cache);

            objBeerDetails = Task.Run(() => objExternalAPIs.GetBeerDetailsFromPunkAPIByName(strBeerName)).Result;

            return objBeerDetails;
        }
    }
}

