using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Vintri_Exercise
{
    public class Program
    {
        private static readonly HttpClient Client = new HttpClient(); // Singleton

        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();

            var analyzer = new SiteAnalyzer(Client);
            var size = analyzer.GetContentSize("http://microsoft.com").Result;
            Console.WriteLine($"Size: {size}");
        }

        public class SiteAnalyzer
        {
            public SiteAnalyzer(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }

            public async Task<int> GetContentSize(string uri)
            {
                var response = await _httpClient.GetAsync(uri);
                var content = await response.Content.ReadAsStringAsync();
                return content.Length;
            }

            private readonly HttpClient _httpClient;
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
