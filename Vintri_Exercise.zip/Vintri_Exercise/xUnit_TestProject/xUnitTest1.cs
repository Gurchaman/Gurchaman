using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Moq.Protected;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Vintri_Exercise.Controllers;
using Xunit;
using static Vintri_Exercise.Program;

namespace xUnit_TestProject
{

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        var analyzer = new SiteAnalyzer(Client);
    //        var size = analyzer.GetContentSize("http://microsoft.com").Result;
    //        Console.WriteLine($"Size: {size}");
    //    }

    //    private static readonly HttpClient Client = new HttpClient(); // Singleton
    //}

  

    public class xUnitTest1
    {
        private IConfiguration _config;
        private readonly IMemoryCache _cache;
        internal static Func<HttpClient> ClientFactory = () => new HttpClient();

        public xUnitTest1()
        {
            IServiceCollection services = new ServiceCollection();

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddMemoryCache();
        }

        public IConfiguration Configuration
        {
            get
            {
                if (_config == null)
                {
                    //var builder = new ConfigurationBuilder().AddJsonFile($"testsettings.json", optional: false);
                    //_config = builder.Build();
                }

                return _config;
            }
        }


        [Fact]
        public async void GetContentSizeReturnsCorrectLength()
        {
            // Arrange
            const string testContent = "test content";
            var mockMessageHandler = new Mock<HttpMessageHandler>();
            mockMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(testContent)
                });
            var underTest = new  SiteAnalyzer(new HttpClient(mockMessageHandler.Object));

            // Act
            var result = await underTest.GetContentSize("https://localhost:44345/API/Beer/GetBeerDetails?Beer");

            // Assert
            Assert.Equal(testContent.Length, result);
        }


        [Fact]
        public void Test1()
        {
            /// Arrange
            var todoService = new Mock<HttpContent>();
            todoService.Setup(_ => _.Headers);

            var client = new HttpClient();
            client = ClientFactory();

            client.BaseAddress = new Uri("https://localhost:44345/API/Beer/GetBeerDetails?Beer");
            //objBeerController.HttpContext.Request.QueryString = new QueryString("?beer_name=Buzz");

            var sut = new BeerController(_config);

            var result = sut.GetBeerDetails();
        }
    }
}
