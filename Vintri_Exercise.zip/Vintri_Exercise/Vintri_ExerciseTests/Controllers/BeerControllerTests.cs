﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Vintri_Exercise.Controllers;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit.Sdk;

namespace Vintri_Exercise.Controllers.Tests
{
    [TestClass()]
    public class BeerControllerTests
    {
        [TestMethod()]
        public void BeerControllerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetBeerDetailsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void AddRatingsTest()
        {
            Assert.Fail();
        }
    }
}