using System;
using Vintri_Exercise.Controllers;
using Xunit;

namespace VintriExcercise_Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            //var controller = new BeerController();
        }
    }
}
