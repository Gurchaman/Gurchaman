using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Vintri_Exercise.Controllers;
using System.Web;
using System.Net;
using System.Security.Policy;
using Vintri_Exercise.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Moq;
using Vintri_Exercise.Filters;
using RichardSzalay.MockHttp;
using System.Net.Http;
using System;
using System.Threading.Tasks;
using NHibernate.Util;

namespace Vintri_UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        private IConfiguration _config;
        private readonly IMemoryCache _cache ;

        public UnitTest1()
        {
            IServiceCollection services = new ServiceCollection();

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddMemoryCache();
        }

        public IConfiguration Configuration
        {
            get
            {
                if (_config == null)
                {
                    var builder = new ConfigurationBuilder().AddJsonFile($"testsettings.json", optional: false);
                    _config = builder.Build();
                }

                return _config;
            }
        }


        [TestMethod]
        public void TestMethod1()
        {
            BeerController objBeerController = new BeerController(_config);
            var dictionary = new Dictionary<string, StringValues>();
            dictionary.Add("Beer", new StringValues("Buzz"));

            var mockHttp = new MockHttpMessageHandler();

            // Setup a respond for the user api (including a wildcard in the URL)
            mockHttp.When("https://localhost:44345/API/Beer/GetBeerDetails?Beer=Buzz")
                    .Respond("application/json", "{'beer_name' : 'Test McGee'}"); // Respond with JSON

            // Inject the handler or client into your application code
            var client = new HttpClient(mockHttp);

            //var response = await client.GetAsync("https://localhost:44345/API/Beer/GetBeerDetails?Beer=Buzz");
            // or without async:
            var response = client.GetAsync("https://localhost:44345/API/Beer/GetBeerDetails?Beer=Buzz").Result;

            var json = Task.Run(() => response.Content.ReadAsStringAsync()).Result;
            //var json = await response.Content.ReadAsStringAsync();

            // No network connection required
            //Console.Write(json); // {'name' : 'Test McGee'}

            //objBeerController.HttpContext.Request.QueryString = new QueryString("?beer_name=Buzz");

            //IHttpWebRequest request = this.WebRequestFactory.Create(_url);

            //HttpContext.Current.Request.QueryString.Add("print", "y");
            //objBeerController.HttpContext.Request.QueryString = new QueryString("?beer_name=Buzz");

            //HttpContext objJ = new HttpContext();
            //objJ.Request.QueryString.Add(new QueryString("?beer_name=Buzz"));

            //HttpContext.Request.Query["Beer"].ToString();
            //QueryCollection objQueryString = new QueryCollection(dictionary);
            //objBeerController.Request.QueryString.Add(new QueryString("?beer_name=Buzz"));

            //objBeerController.Request.Query = new QueryCollection(dictionary);

            var httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri("https://localhost:44345/API/Beer/GetBeerDetails?Beer");
            var r = httpClient.GetAsync("https://localhost:44345/API/Beer/GetBeerDetails?Beer");

            //var httpContext = new HttpContext(httpClient);

            var result = objBeerController.GetBeerDetails();

            Assert.AreEqual(typeof(UnitTest1), typeof(UnitTest1));
        }

        //[TestMethod]
        //[MyActionFilter]
        //public void AddRatings_Test()
        //{
        //    BeerController objBeerController = new BeerController(_config);

        //    objBeerController.HttpContext.

        //    int ID = 4;
        //    UserRatingsModel userRatingsModel = new UserRatingsModel();
        //    userRatingsModel.UserName = "ABC@Gmail.com";
        //    userRatingsModel.Comments = "It is a nice beer";
        //    userRatingsModel.Ratings = 5;

        //    //Invalid_ModelState_Should_Return_BadRequestObjectResult();
        //    var result = objBeerController.AddRatings(ID, userRatingsModel);
        //    var expectedResult = "{\r\n    \"message\": \"Rating successfully shared. Thank You !\"\r\n}";

        //    Assert.AreEqual(JsonConvert.SerializeObject(expectedResult), JsonConvert.SerializeObject(result));

        //}

        
        public void Invalid_ModelState_Should_Return_BadRequestObjectResult()
        {
            //Arrange
            var modelState = new ModelStateDictionary();
            modelState.AddModelError("", "error");
            var httpContext = new DefaultHttpContext();
            var context = new ActionExecutingContext(
                new ActionContext(
                    httpContext: httpContext,
                    routeData: new Microsoft.AspNetCore.Routing.RouteData(),
                    actionDescriptor: new ActionDescriptor(),
                    modelState: modelState
                ),
                new List<IFilterMetadata>(),
                new Dictionary<string, object>(),
                new Mock<Controller>().Object);

            var sut = new MyActionFilter();

            //Act
            sut.OnActionExecuting(context);

            //Assert
            //context.Result.Should().NotBeNull()
            //    .And.BeOfType<BadRequestObjectResult>();
        }



        //public void AcceptsTypeFilterJson_RequestHeaderAcceptsJson_ReturnsJson()
        //{
        //    var context = new ActionExecutedContext();
        //    context.HttpContext = // mock an http context and set the accept-type. I don't know how to do this, but there are many questions about it.
        //    context.Result = new ViewResult(...); // What your controller would return
        //    var filter = new AcceptTypesAttribute(HttpContentTypes.Json);

        //    filter.OnActionExecuted(context);

        //    Assert.True(context.Result is JsonResult);
        //}
    }

    //[TestClass]
    //public class ValidateModelAttributeTest
    //{
    //    [TestMethod]
    //    public void Invalid_ModelState_Should_Return_BadRequestObjectResult()
    //    {
    //        //Arrange
    //        var modelState = new ModelStateDictionary();
    //        modelState.AddModelError("", "error");
    //        var httpContext = new DefaultHttpContext();
    //        var context = new ActionExecutingContext(
    //            new ActionContext(
    //                httpContext: httpContext,
    //                routeData: new Microsoft.AspNetCore.Routing.RouteData(),
    //                actionDescriptor: new ActionDescriptor(),
    //                modelState: modelState
    //            ),
    //            new List<IFilterMetadata>(),
    //            new Dictionary<string, object>(),
    //            new Mock<Controller>().Object);

    //        var sut = new MyActionFilter();

    //        //Act
    //        sut.OnActionExecuting(context);

    //        //Assert
    //        //context.Result.Should().NotBeNull()
    //        //    .And.BeOfType<BadRequestObjectResult>();
    //    }
    //}
}
