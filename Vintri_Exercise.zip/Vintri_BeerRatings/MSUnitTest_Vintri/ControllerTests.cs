using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using Vintri_Exercise.Controllers;

namespace MSUnitTest_Vintri
{
    [TestClass]
    public class ControllerTests
    {
        private IConfiguration _config;

        public ControllerTests()
        {
            IServiceCollection services = new ServiceCollection();

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddMemoryCache();
        }

        public IConfiguration Configuration
        {
            get
            {
                if (_config == null)
                {
                    var builder = new ConfigurationBuilder().AddJsonFile($"testSettings.json", optional: false);
                    _config = builder.Build();
                }

                return _config;
            }
        }

        private BeerController GetControllerDetails(string strBeerName)
        {
            var services = new ServiceCollection();
            services.AddMemoryCache();
            var serviceProvider = services.BuildServiceProvider();
            var memoryCache = serviceProvider.GetService<IMemoryCache>();
            BeerController controller = new BeerController(_config, memoryCache);

            Mock<HttpContext> mockHttpContext = new Mock<HttpContext>();
            mockHttpContext.Setup(s => s.Request.QueryString).Returns(new QueryString("?beer=" + Convert.ToString(strBeerName)));
            controller.ControllerContext.HttpContext = mockHttpContext.Object;

            return controller;
        }

        [TestMethod]
        public void GetBeerDetails_With_Empty_BeerName()
        {
            // Arrange
            BeerController controller =  GetControllerDetails("");

            // Act
            var varResult = controller.GetBeerDetails();
            
            // Assert
            Assert.AreEqual("", varResult.Value.ToString());
        }

        [TestMethod]
        public void GetBeerDetails_With_Correct_BeerName()
        {
            // Arrange
            BeerController controller = GetControllerDetails("Buzz");

            // Act
            var varResult = controller.GetBeerDetails();

            // Assert
            Assert.IsTrue(varResult.GetType().Name.Equals("JsonResult"));
        }
    }
}
