﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Vintri_BeerRatings;
using Vintri_BeerRatings.Filters;
using Vintri_BeerRatings.Models;
using Vintri_BeerRatings.Services;

namespace Vintri_Exercise.Controllers
{
    [ApiController]
    [Route("API/")]
    public class BeerController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;
        IList<BeerDetailsModel> objBeerDetails = new List<BeerDetailsModel>();

        public BeerController(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _cache = memoryCache;
        }


        /// <summary>
        /// Method to search beer details
        /// </summary>
        /// <returns>Returns matching results in JSON format</returns>
        [HttpGet]
        [Route("Beer/GetBeerDetails")]
        public JsonResult GetBeerDetails()
        {
            List<SaveBeerRatingsModel> listBeerRatingsModel = new List<SaveBeerRatingsModel>();
            string strBeerName = String.Empty;

            try
            {
                strBeerName = HttpContext.Request.QueryString.ToString();                                        // Take out the query string data 
                if (strBeerName.Contains("?beer=", StringComparison.OrdinalIgnoreCase))
                    strBeerName = strBeerName.Substring(strBeerName.IndexOf("=") + 1);

                if (!string.IsNullOrEmpty(strBeerName))
                {
                    objBeerDetails = GetAllBeerDetails(strBeerName); 

                    var varFilePath = @"./Database/Database.json";
                    var varJsonData = System.IO.File.ReadAllText(varFilePath);
                    listBeerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(varJsonData);  // Get the saved data from JSON database

                    var varBeerData = from beers in objBeerDetails
                                      join ratings in listBeerRatingsModel
                                      on beers.id equals ratings.Id
                                      select new
                                      {
                                          id = beers.id,
                                          name = beers.name,
                                          description = beers.description,
                                          userRatings = ratings.UserRatings
                                      };

                    return new JsonResult(varBeerData);              // Return the data with required details.
                }
                else
                    return new JsonResult("");                       // If no data found, return empty data. Could return a relevant message as well.
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());    // In real world, would log this message in the system log file or the Log database.
                return new JsonResult("");                   // Or send an error message. In that case, API consumer needs to know how error messages would be delivered.
            }
        }


        /// <summary>
        /// Adds Ratings for a Beer
        /// </summary>
        /// <param name="ID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings in the range of 1 and 5</param>
        /// <returns>Success/failure message</returns>
        [HttpPost]
        [Route("Beer/AddRatings/{ID}")]
        [MyActionFilter]
        public ActionResult AddRatings(int ID, [FromBody] UserRatingsModel objUserRatings)
        {
            string strMessage = string.Empty;

            try
            {
                if (RouteData.Values["InvalidUserName"] != null)          // Check if custom attribute found any issue with the UserName EmailID regex
                    return new JsonResult(new { Message = RouteData.Values["InvalidUserName"] });

                strMessage = Validations(ID, objUserRatings);

                if (string.IsNullOrEmpty(strMessage))                     // If there is no validation error, procced further saving the data.
                {
                    if (SaveToJSONDatabase(ID, objUserRatings))           // Saving to JSON Database
                        return new JsonResult(new { Message = Messages.SuccessRating });
                    else
                        return new JsonResult(new { Message = Messages.Error });
                }
                else
                {
                    return new JsonResult(new { Message = strMessage });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());                 // In real world, would log this message in the system log file or database
                return new JsonResult(new { Message = Messages.Error });
            }
        }

        /// <summary>
        /// Saves data to the JSON Database
        /// </summary>
        /// <param name="intID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings of the beer</param>
        /// <returns></returns>
        private bool SaveToJSONDatabase(int intID, UserRatingsModel objUserRatings)
        {
            string strData = string.Empty;
            bool blnExistingBeer = false;
            bool blnExistingBeerForUser = false;
            var varFilePath = @"./Database/Database.json";
            List<SaveBeerRatingsModel> listBeerRatingsModel = new List<SaveBeerRatingsModel>();

            try
            {
                var varJsonData = System.IO.File.ReadAllText(varFilePath);   // Reading data from JSON Database

                // If the file is empty
                if (string.IsNullOrEmpty(varJsonData))                        // If no data is present, simply save it as we donot need to append it to any data at this stage
                {
                    listBeerRatingsModel.Insert(0, AddRatingsToABeer(intID, objUserRatings));   
                }
                else
                {
                    // If there is some data already present, then first get the existing data. Then push new data to it and then save the new JSON so formed in JSON Database.

                    listBeerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(varJsonData);    // Deseralizing the current data

                    foreach (SaveBeerRatingsModel itemBeer in listBeerRatingsModel)
                    {
                        if (itemBeer.Id.Equals(intID))
                        {
                            blnExistingBeer = true;                             // Means check if beer data already exists in the saved JSON

                            foreach (UserRatingsModel itemRating in itemBeer.UserRatings)
                            {
                                if (itemRating.UserName.Equals(objUserRatings.UserName, StringComparison.OrdinalIgnoreCase))
                                {
                                    blnExistingBeerForUser = true;
                                    itemRating.Ratings = objUserRatings.Ratings;  // If same user is sharing rating for same beer again, then just 'Replace' the rating value
                                    itemRating.Comments = objUserRatings.Comments;
                                }
                            }

                            if (!blnExistingBeerForUser)
                                itemBeer.UserRatings.Add(objUserRatings);         // If a user is sharing the rating for the first time for a particular beer, 'Add' it

                        }
                    }
                    if (!blnExistingBeer)
                        listBeerRatingsModel.Insert(0, AddRatingsToABeer(intID, objUserRatings));  // Once the data is prepared, insert it in the list
                }

                var varOptions = new JsonSerializerOptions { WriteIndented = true };
                strData = JsonSerializer.Serialize(listBeerRatingsModel, varOptions);

                System.IO.File.WriteAllText(@"./Database/Database.json", strData);  // Saving the JSON

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());    // In real world, would log this message in the system log file or the Log database
                throw;                                       // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }


        /// <summary>
        /// Method to prepare the ratings model
        /// </summary>
        /// <param name="intID">ID of the Beer</param>
        /// <param name="objUserRatings">Rating of the beer</param>
        /// <returns>Ratings data in the form of model</returns>
        private SaveBeerRatingsModel AddRatingsToABeer(int intID, UserRatingsModel objUserRatings)
        {
            SaveBeerRatingsModel objBeerRatingsModel = new SaveBeerRatingsModel();

            objBeerRatingsModel.Id = intID;
            objBeerRatingsModel.UserRatings = new List<UserRatingsModel>();
            objBeerRatingsModel.UserRatings.Add(objUserRatings);

            return objBeerRatingsModel;
        }


        /// <summary>
        /// Validates the Rating data
        /// </summary>
        /// <param name="intID">ID of the beer</param>
        /// <param name="objUserRatings">Ratings given to the beer</param>
        /// <returns>Error message of there is any error, else empty string</returns>
        private string Validations(int intID, UserRatingsModel objUserRatings)
        {
            ExternalAPIs objExternalAPIs = new ExternalAPIs(_configuration, _cache);
            objBeerDetails = Task.Run(() => objExternalAPIs.GetBeerDetailsFromPunkAPIByID(intID)).Result;

            // Ensure the id parameter is a valid beer id
            if (objBeerDetails == null || objBeerDetails.Count < 1)
                return Messages.InValidBeerID;

            // Ensure that the rating is a valid value in the range of 1 to 5
            if (!(objUserRatings.Ratings >= 0 && objUserRatings.Ratings <= 5))
                return Messages.InValidRating;

            return string.Empty;                             // If validations goes fine, return an empty string 
        }


        /// <summary>
        /// Calls the Beer Punk API method
        /// </summary>
        /// <returns>Returns details of all the beers</returns>
        private IList<BeerDetailsModel> GetAllBeerDetails(string strBeerName)
        {
            try
            {
                ExternalAPIs objExternalAPIs = new ExternalAPIs(_configuration, _cache);                                // Setting up the constructor

                objBeerDetails = Task.Run(() => objExternalAPIs.GetBeerDetailsFromPunkAPIByName(strBeerName)).Result;   // Calls API here

                return objBeerDetails;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());     // In real world, would log this message in the system log file or database
                throw;                                        // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }
    }
}

