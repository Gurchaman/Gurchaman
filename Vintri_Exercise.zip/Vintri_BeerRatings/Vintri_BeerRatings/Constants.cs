﻿namespace Vintri_BeerRatings
{
    public static class Constants
    {
        public static string UserNameRegex = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
    }
}
