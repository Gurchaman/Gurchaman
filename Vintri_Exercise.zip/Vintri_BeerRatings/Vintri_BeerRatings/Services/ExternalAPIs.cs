﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Vintri_BeerRatings.Models;

namespace Vintri_BeerRatings.Services
{
    public class ExternalAPIs
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;

        public ExternalAPIs(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _cache = memoryCache;
        }

        /// <summary>
        /// Gets Punk API data by beer name search 
        /// </summary>
        /// <param name="intID">ID of the beer</param>
        /// <returns>Data of the beer</returns>
        public async Task<IList<BeerDetailsModel>> GetBeerDetailsFromPunkAPIByID(int intID)
        {
            IList<BeerDetailsModel> objBeerDetails = new List<BeerDetailsModel>();

            try
            {
                using (var httpClient = new HttpClient())
                {
                    using (var response = await httpClient.GetAsync((_configuration.GetSection("PunkAPIByID").Value) + Convert.ToString(intID)))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        objBeerDetails = JsonConvert.DeserializeObject<IList<BeerDetailsModel>>(apiResponse);
                    }
                }

                return objBeerDetails;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;                   // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }

        /// <summary>
        /// Gets Punk API data by Beer name search
        /// </summary>
        /// <param name="strBeerName">Beer Name</param>
        /// <returns>Data of the Beer</returns>
        public async Task<IList<BeerDetailsModel>> GetBeerDetailsFromPunkAPIByName(string strBeerName)
        {
            IList<BeerDetailsModel> objBeerDetails = new List<BeerDetailsModel>();
            IList<BeerDetailsModel> objBeerDetailsResult = new List<BeerDetailsModel>();
            bool blnAlreadyExists = false;

            try
            {
                // Just to demonstrate the concept of caching, caching the data for 30 seconds only. And even that is configurable in appsettings.json.

                blnAlreadyExists = _cache.TryGetValue("BeerDetails", out objBeerDetails);

                if (!blnAlreadyExists)
                {
                    using (var httpClient = new HttpClient())
                    {
                        using (var response = await httpClient.GetAsync((_configuration.GetSection("PunkAPI").Value)))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            objBeerDetails = JsonConvert.DeserializeObject<IList<BeerDetailsModel>>(apiResponse);
                        }
                    }

                    DateTimeOffset objDateTimeOffSet = new DateTimeOffset(DateTime.Now.AddSeconds(Convert.ToDouble(_configuration.GetSection("PunkAPICachingTime").Value)));
                    _cache.Set("BeerDetails", objBeerDetails, objDateTimeOffSet);
                }
                else
                {
                    objBeerDetails = (IList<BeerDetailsModel>)_cache.Get("BeerDetails");
                }


                foreach(BeerDetailsModel item in objBeerDetails)
                    if (item.name.Equals(strBeerName, StringComparison.OrdinalIgnoreCase))
                        objBeerDetailsResult.Add(item);

                return objBeerDetailsResult;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;                   // Always use throw instead of 'throw ex'. throw provides good stack trace
            }

        }
    }
}
