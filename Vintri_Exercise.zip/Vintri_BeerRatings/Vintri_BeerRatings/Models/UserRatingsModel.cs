﻿using System.Collections.Generic;

namespace Vintri_BeerRatings.Models
{
    public class UserRatingsModel
    {
        public string UserName { get; set; }
        public int Ratings { get; set; }
        public string Comments { get; set; }
    }

    public class SaveBeerRatingsModel
    {
        public int Id { get; set; }

        public IList<UserRatingsModel> UserRatings { get; set; }
    }

    public class BeerRatingsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public IList<UserRatingsModel> UserRatings { get; set; }
    }
}
